package com.my.maybank.customer.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	private final String DDMMYYYYHHMMSS = "ddMMyyyyHHmmss";

	public static String getFormattedDate(Date date, String format) {

		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}
}
