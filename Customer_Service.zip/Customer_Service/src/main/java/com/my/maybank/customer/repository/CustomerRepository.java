package com.my.maybank.customer.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.my.maybank.customer.entity.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Long> {

	@Transactional
	@Query("UPDATE Customer SET description = ?1 WHERE id = ?2")
	void updateDescription(String description, String id);
	
	@Query("SELECT t FROM Customer t WHERE t.id = ?1")
	Optional<Customer> findById(String token);
	
	Page<Customer> findByAccountNumber(String accountNumber, Pageable pageable);
	
	Page<Customer> findByDescription(String description, Pageable pageable);
	
	Page<Customer> findByCustomerId(String customerId, Pageable pageable);
}
