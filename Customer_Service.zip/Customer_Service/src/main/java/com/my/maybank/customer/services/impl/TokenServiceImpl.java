package com.my.maybank.customer.services.impl;

import java.time.LocalDateTime;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.maybank.customer.entity.UserToken;
import com.my.maybank.customer.exception.PortalCoreException;
import com.my.maybank.customer.repository.UserTokenRepository;
import com.my.maybank.customer.services.TokenService;

@Service
@Transactional
public class TokenServiceImpl implements TokenService {

	@Autowired
	private UserTokenRepository userTokenRepository;

	@Override
	public UserToken saveuserToken(String userName, String token) {
		return userTokenRepository.save(new UserToken(userName, token));
	}

	@Override
	public UserToken findByToken(String token) throws PortalCoreException {
		return userTokenRepository.findByToken(token)
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid toke (Token not found"));
	}

	@Override
	public UserToken findByid(String id) throws PortalCoreException {
		return userTokenRepository.findById(id)
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid toke (Token not found"));
	}

	@Override
	public void invalidateById(String id) throws PortalCoreException {

		UserToken userToken = userTokenRepository.findById(id)
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid toke (Token not found"));
		userToken.setIs_valid("0");
		userToken.setDateInvalidate(LocalDateTime.now());
		userTokenRepository.save(userToken);
	}

	@Override
	public void invalidateByToken(String token) throws PortalCoreException {

		UserToken userToken = userTokenRepository.findByToken(token)
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid toke (Token not found"));
		userToken.setIs_valid("0");
		userToken.setDateInvalidate(LocalDateTime.now());
		userTokenRepository.save(userToken);
	}

}
