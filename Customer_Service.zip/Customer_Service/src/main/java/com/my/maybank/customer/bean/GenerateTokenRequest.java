package com.my.maybank.customer.bean;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GenerateTokenRequest {

	@JsonProperty("userName")
	@Size(max = 150)
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
}
