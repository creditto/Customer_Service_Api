package com.my.maybank.customer.dto;

public class CustomerDTO {

	private String account_Number;

	private Double txn_amount;

	private String description;

	private String trxDate;

	private String trxTime;

	private String customerId;

	public CustomerDTO() {
	}

	public CustomerDTO(String account_Number, String txn_amount, String description, String trxDate, String trxTime,
			String customerId) {

		this.account_Number = account_Number;
		this.txn_amount = Double.parseDouble(txn_amount);
		this.description = description;
		this.trxDate = trxDate;
		this.trxTime = trxTime;
		this.customerId = customerId;
	}
	
	public CustomerDTO(String account_Number, Double txn_amount, String description, String trxDate, String trxTime,
			String customerId) {

		this.account_Number = account_Number;
		this.txn_amount = txn_amount;
		this.description = description;
		this.trxDate = trxDate;
		this.trxTime = trxTime;
		this.customerId = customerId;
	}

	public String getAccount_Number() {
		return account_Number;
	}

	public Double getTxn_amount() {
		return txn_amount;
	}

	public String getDescription() {
		return description;
	}

	public String getTrxDate() {
		return trxDate;
	}

	public String getTrxTime() {
		return trxTime;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setAccount_Number(String account_Number) {
		this.account_Number = account_Number;
	}

	public void setTxn_amount(Double txn_amount) {
		this.txn_amount = txn_amount;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}

	public void setTrxTime(String trxTime) {
		this.trxTime = trxTime;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}
