package com.my.maybank.customer.services;

import com.my.maybank.customer.entity.UserToken;
import com.my.maybank.customer.exception.PortalCoreException;

public interface TokenService {

	UserToken saveuserToken(String userName, String token);

	UserToken findByToken(String token) throws PortalCoreException;
	
	UserToken findByid(String token) throws PortalCoreException;
	
	void invalidateById(String id) throws PortalCoreException;
	
	void invalidateByToken(String token) throws PortalCoreException;
}
