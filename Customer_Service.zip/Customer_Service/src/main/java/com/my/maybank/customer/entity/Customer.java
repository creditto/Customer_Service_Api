package com.my.maybank.customer.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "CUSTOMER")
public class Customer {

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Size(max = 20)
	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name = "TXN_AMOUNT")
	private Double txn_amount;

	@Size(max = 100)
	@Column(name = "DESCRIPTION")
	private String description;

	@Size(max = 20)
	@Column(name = "TRX_DATE")
	private String trxDate;

	@Size(max = 20)
	@Column(name = "TRX_TIME")
	private String trxTime;

	@Size(max = 10)
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Size(max = 20)
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	@Column(name = "UPDATED_ON")
	private LocalDateTime updatedOn;
	
	public Customer() {
	}
	public Customer(String accountNumber, Double txn_amount, String description, String trxDate, String trxTime,
			String customerId) {

		this.accountNumber = accountNumber;
		this.txn_amount = txn_amount;
		this.description = description;
		this.trxDate = trxDate;
		this.trxTime = trxTime;
		this.customerId = customerId;
	}

	public Long getId() {
		return id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public Double getTxn_amount() {
		return txn_amount;
	}

	public String getDescription() {
		return description;
	}

	public String getTrxDate() {
		return trxDate;
	}

	public String getTrxTime() {
		return trxTime;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setTxn_amount(Double txn_amount) {
		this.txn_amount = txn_amount;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}

	public void setTrxTime(String trxTime) {
		this.trxTime = trxTime;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

}
