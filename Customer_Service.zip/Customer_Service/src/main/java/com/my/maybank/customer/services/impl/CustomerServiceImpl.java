package com.my.maybank.customer.services.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.my.maybank.customer.dao.CustomerDao;
import com.my.maybank.customer.dto.CustomerDTO;
import com.my.maybank.customer.exception.PortalCoreException;
import com.my.maybank.customer.services.CustomerService;
import com.my.maybank.customer.util.DateUtil;

@Service
public class CustomerServiceImpl implements CustomerService {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private CustomerDao customerDao;

	@Value("${Flat.file.location}")
	private String location;

	@Value("${Flat.file.name}")
	private String fileName;
	
	@Value("${Flat.file.processed}")
	private String processed;

	public void extractCustomerFlatFile() {


		Path file = Paths.get(location + File.separator + fileName);

		if (file.toFile().exists()) {

			try {
				Stream<String> entries = Files.lines(file);

				List<CustomerDTO> customerDTOList = getList(entries);

				customerDao.save(customerDTOList);
				
				File processedFolderPath = new File(processed);
				
				if (!processedFolderPath.exists()) {
					processedFolderPath.mkdir();
				}
				
				File destinationFile = new File(processedFolderPath + File.separator
                        + FilenameUtils.removeExtension(fileName) + "_"
                        + DateUtil.getFormattedDate(new Date(), "ddMMyyyyHHmmss") + ".txt");

                FileUtils.moveFile(file.toFile(), destinationFile);

                log.info("File : " + file.toFile().getName() + " move to processed folder");

			} catch (IOException e) {
				log.info("Exception occur while read the flat file");
			}

		} else {
			log.info("Flat file is does not exist");
		}

		log.info("Ended extractCustomerFlatFile ", new Date());
	}

	@Override
	public void updateDescription(String id, String description, String updatedBy) throws PortalCoreException {
		customerDao.updateDescription(id, description, updatedBy);
	}

	@Override
	public List<CustomerDTO> getCustomerDetailsList(String searchBy, String searchValue, Integer pageNo,
			Integer pageSize) throws PortalCoreException {
		return customerDao.getCustomerDetailsList(searchBy, searchValue, pageNo, pageSize);
	}

	private List<CustomerDTO> getList(Stream<String> entries) {

		return entries.map(e -> StringUtils.splitByWholeSeparatorPreserveAllTokens(e, "|")).skip(1)
				.filter(tokens -> tokens != null && tokens.length == 6)
				.map(tokens -> new CustomerDTO(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]))
				.collect(Collectors.toList());
	}
}
