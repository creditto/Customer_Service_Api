package com.my.maybank.customer.controller;

import java.util.Collections;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.my.maybank.customer.exception.MainBasedBean;
import com.my.maybank.customer.exception.PortalCoreException;
import com.my.maybank.customer.exception.ServicefaultDetail;
import com.my.maybank.customer.exception.ValidationInputException;

@RestController
@ControllerAdvice
public class CustomerServiceControllerAdvice {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerServiceControllerAdvice.class);

	@ExceptionHandler(PortalCoreException.class)
	public ResponseEntity<ServicefaultDetail> hadnleException(PortalCoreException portalCoreException,
			HttpServletRequest servletRequest) {

		ServicefaultDetail servicefaultDetail = new ServicefaultDetail();

		MainBasedBean MainBasedBean = new MainBasedBean();
		MainBasedBean.setErrorCode(portalCoreException.getErrorCode());
		MainBasedBean.setMessage(portalCoreException.getErrorMessage());

		HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

		Throwable cause = portalCoreException.getCause();

		if (cause == null) {
			httpStatus = HttpStatus.ACCEPTED;
		} else if (cause instanceof ValidationInputException) {

			ValidationInputException inputException = (ValidationInputException) cause;

			String errorMessage = inputException.getErrors().getAllErrors().stream()
					.map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList()).toString();
			errorMessage = errorMessage.substring(1, errorMessage.length() - 1);
			MainBasedBean.setMessage(errorMessage);
		}

		servicefaultDetail.setError(MainBasedBean);

		return ResponseEntity.status(httpStatus).body(servicefaultDetail);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> hadnleException(Exception ex, HttpServletRequest servletRequest) {
		LOGGER.error(ex.getMessage(), ex);

		return ResponseEntity.accepted().body(Collections.singletonList(Collections.singletonMap("errorCode", "500")));

	}
	
	@ExceptionHandler({
		MissingServletRequestParameterException.class,
		MethodArgumentTypeMismatchException.class
	})
	@ResponseBody
	public ResponseEntity<ServicefaultDetail> hadnleException(Exception e) {
		
		ServicefaultDetail servicefaultDetail = new ServicefaultDetail();

		MainBasedBean MainBasedBean = new MainBasedBean();
		MainBasedBean.setErrorCode("400");
		MainBasedBean.setMessage(e.getMessage());
		
		servicefaultDetail.setError(MainBasedBean);

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(servicefaultDetail);		
	}
}
