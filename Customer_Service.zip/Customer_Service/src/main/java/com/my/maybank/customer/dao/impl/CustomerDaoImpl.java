package com.my.maybank.customer.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.my.maybank.customer.bean.SearchType;
import com.my.maybank.customer.dao.CustomerDao;
import com.my.maybank.customer.dto.CustomerDTO;
import com.my.maybank.customer.entity.Customer;
import com.my.maybank.customer.exception.PortalCoreException;
import com.my.maybank.customer.repository.CustomerRepository;

@Service
@Transactional
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public void save(List<CustomerDTO> customerDTOList) {

		for (@SuppressWarnings("rawtypes")
		Iterator iterator = customerDTOList.iterator(); iterator.hasNext();) {
			CustomerDTO customerDTO = (CustomerDTO) iterator.next();

			save(customerDTO);
		}
	}

	@Override
	public void updateDescription(String id, String description, String updatedBy) throws PortalCoreException {

		Customer customer = customerRepository.findById(Long.parseLong(id))
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid Id (Id not found"));
		customer.setDescription(description);
		customer.setUpdatedBy(updatedBy);
		customer.setUpdatedOn(LocalDateTime.now());
		customerRepository.save(customer);

	}

	@Override
	public List<CustomerDTO> getCustomerDetailsList(String searchBy, String searchValue, Integer pageNo,
			Integer pageSize) throws PortalCoreException {

		Page<Customer> customerList = null;

		Pageable paging = PageRequest.of(pageNo, pageSize);

		if (searchBy.equalsIgnoreCase(SearchType.CUSTOMER_ID.name())) {
			customerList = customerRepository.findByCustomerId(searchValue, paging);
		} else if (searchBy.equalsIgnoreCase(SearchType.DESCRIPTION.name())) {
			customerList = customerRepository.findByDescription(searchValue, paging);
		} else if (searchBy.equalsIgnoreCase(SearchType.ACCOUNT_NUMBER.name())) {
			customerList = customerRepository.findByAccountNumber(searchValue, paging);
		} else {
			throw new PortalCoreException("E04", "Invalid Search By option");
		}

		if (customerList == null || customerList.isEmpty()) {
			throw new PortalCoreException("E05", "No Data");
		}

		List<Customer> customersList = new ArrayList<Customer>();

		customersList = customerList.getContent();

		List<CustomerDTO> customerDTOList = new ArrayList<CustomerDTO>();

		for (Iterator iterator = customersList.iterator(); iterator.hasNext();) {
			Customer customer = (Customer) iterator.next();

			customerDTOList.add(new CustomerDTO(customer.getAccountNumber(), customer.getTxn_amount(),
					customer.getDescription(), customer.getTrxDate(), customer.getTrxTime(), customer.getCustomerId()));
		}

		return customerDTOList;
	}

	public Customer findById(String id) throws PortalCoreException {
		return customerRepository.findById(id)
				.orElseThrow(() -> new PortalCoreException("E04", "Invalid Id (Id not found"));
	}

	public Customer save(CustomerDTO customerDTO) {
		return customerRepository.save(
				new Customer(customerDTO.getAccount_Number(), customerDTO.getTxn_amount(), customerDTO.getDescription(),
						customerDTO.getTrxDate(), customerDTO.getTrxTime(), customerDTO.getCustomerId()));
	}

}
