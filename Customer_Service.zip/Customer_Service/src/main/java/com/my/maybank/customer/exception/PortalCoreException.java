package com.my.maybank.customer.exception;

public class PortalCoreException extends Exception {

	private String errorCode;
	private String errorMessage;

	public PortalCoreException(String errorCode, String message) {
		this(errorCode, message, null);
	}

	public PortalCoreException(String errorCode, Throwable throwable) {
		this(errorCode, throwable.getMessage(), throwable);
	}

	public PortalCoreException(String errorCode, String message, Throwable throwable) {
		super(errorCode, throwable);
		this.errorCode = errorCode;
		this.errorMessage = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
