package com.my.maybank.customer.exception;

public class ServicefaultDetail {

	private MainBasedBean error;

	public MainBasedBean getError() {
		return error;
	}

	public void setError(MainBasedBean error) {
		this.error = error;
	}

}
